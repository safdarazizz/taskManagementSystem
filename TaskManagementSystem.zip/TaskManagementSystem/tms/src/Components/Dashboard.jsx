import React from "react";

const Dashboard = () => {
  return (
    <div>
      <nav className="bg-orange-400 text-center p-2 rounded-lg">
        Task Manager Dashboard
      </nav>
    </div>
  );
};

export default Dashboard;
