package org.jsp.springEnumProject.dao;

import java.util.List;
import java.util.Optional;

import org.jsp.springEnumProject.entity.A_2Task;
import org.jsp.springEnumProject.repository.A_8TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class A_7TaskDao {
	
	@Autowired
	private A_8TaskRepository repository;

	public A_2Task saveTask(A_2Task task)
	{
		return repository.save(task);
	}
	
	public A_2Task updateTask(A_2Task task)
	{
		return repository.save(task);
	}
	
	public Optional<A_2Task> findTaskById(int id)
	{
		return repository.findById(id);
	}
	
	public List<A_2Task> findAllTasks()
	{
		return repository.findAll();
	}
}
