package org.jsp.springEnumProject.controller;

import java.util.List;

import org.jsp.springEnumProject.A_5ResponseStructure;
import org.jsp.springEnumProject.entity.A_2Task;
import org.jsp.springEnumProject.service.A_6TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tasks")
@CrossOrigin(origins = "*") // CORS -> Cross Origin Resource Sharing is used to share resource between two softwares // This class becomes eligible to take request from any client (in this case react which is localhost 3000)
public class A_4TaskController {
	
	@Autowired
	private A_6TaskService service;
	
	@PostMapping
	public ResponseEntity<A_5ResponseStructure<A_2Task>> saveTask(@RequestBody A_2Task task)
	{
		return service.saveTask(task);
	}
	
//	@PutMapping
//	public ResponseEntity<A_5ResponseStructure<A_2Task>> updateTask(@RequestBody A_2Task task)
//	{
//		return service.updateTask(task);
//	}
	
	@GetMapping
	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllTasks()
	{
		return service.findAllTasks();
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<A_5ResponseStructure<A_2Task>> findTaskById(@PathVariable int id)
	{
		return service.findTaskById(id);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<A_5ResponseStructure<String>> deleteTaskById(@PathVariable int id)
	{
		return service.deleteTaskById(id);
	}
	
	@GetMapping("/pending")
	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllPendingTasks()
	{
		return service.findAllPendingTasks();
	}
	
	@GetMapping("/completed")
	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllCompletedTasks()
	{
		return service.findAllCompletedTasks();
	}
	
	@GetMapping("/deleted")
	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllDeletedTasks()
	{
		return service.findAllDeletedTasks();
	}
	
	@PatchMapping("/completed/{id}") // for partial update
	public ResponseEntity<A_5ResponseStructure<A_2Task>> setStatusToCompleted(@PathVariable int id)
	{
		return service.setStatusToCompleted(id);
	}
	
	@PatchMapping("/pending/{id}")
	public ResponseEntity<A_5ResponseStructure<A_2Task>> setStatusToPending(@PathVariable int id)
	{
		return service.setStatusToPending(id);
	}
	
	@PatchMapping("/deleted/{id}")
	public ResponseEntity<A_5ResponseStructure<A_2Task>> setStatusToDeleted(@PathVariable int id)
	{
		return service.setStatusToDeleted(id);
	}
}
