package org.jsp.springEnumProject;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class A_5ResponseStructure<T> {
	
	private int httpCode;
	private String message;
	private T body;
}
