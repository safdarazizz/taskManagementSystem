package org.jsp.springEnumProject.repository;

import org.jsp.springEnumProject.entity.A_2Task;
import org.springframework.data.jpa.repository.JpaRepository;

public interface A_8TaskRepository extends JpaRepository<A_2Task, Integer> {

}
