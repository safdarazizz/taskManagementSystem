package org.jsp.springEnumProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class A_1SpringBootEnumProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(A_1SpringBootEnumProjectApplication.class, args);
	}

}
