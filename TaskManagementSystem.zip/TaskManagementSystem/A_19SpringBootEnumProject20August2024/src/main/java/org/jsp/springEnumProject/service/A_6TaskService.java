package org.jsp.springEnumProject.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.jsp.springEnumProject.A_5ResponseStructure;
import org.jsp.springEnumProject.dao.A_7TaskDao;
import org.jsp.springEnumProject.entity.A_2Task;
import org.jsp.springEnumProject.exception.A_9InvalidTaskIdException;
import org.jsp.springEnumProject.util.A_3Status;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class A_6TaskService {

	@Autowired
	private A_7TaskDao dao;
	
//	public ResponseEntity<A_5ResponseStructure<A_2Task>> saveTask(A_2Task task)
//	{
////		if(A_3Status.PENDING.equals(task.getStatus().toString().toUpperCase()))
////		{
////			task.setStatus(A_3Status.PENDING);
////		}
//		
//		A_2Task dbTask = dao.saveTask(task);
//		
//		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
//		structure.setHttpCode(HttpStatus.CREATED.value());
//		structure.setMessage("Task Created Successfully");
//		structure.setBody(dbTask);
//		
//		return new ResponseEntity<>(structure, HttpStatus.CREATED);
//	}

//	public ResponseEntity<A_5ResponseStructure<A_2Task>> updateTask(A_2Task task)
//	{
//		A_2Task dbTask = dao.updateTask(task);
//		
//		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
//		structure.setHttpCode(HttpStatus.OK.value());
//		structure.setMessage("Task Updated Successfully");
//		structure.setBody(dbTask);
//		
//		return new ResponseEntity<>(structure, HttpStatus.OK);
//	}

	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllTasks()
	{
		List<A_2Task> listOfTasks = dao.findAllTasks();
		
		ArrayList<A_2Task> al = new ArrayList<>();
		
		for(A_2Task t : listOfTasks)
		{
			if(!t.getStatus().toString().equalsIgnoreCase("DELETED"))
				al.add(t);
		}
		
		A_5ResponseStructure<List<A_2Task>> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("All Tasks Found Successfully");
		structure.setBody(al);
		
		return new ResponseEntity<A_5ResponseStructure<List<A_2Task>>>(structure, HttpStatus.OK);
	}

	public ResponseEntity<A_5ResponseStructure<A_2Task>> findTaskById(int id)
	{
		Optional<A_2Task> optional = dao.findTaskById(id);
		
		if(optional.isEmpty())
		{
			throw new A_9InvalidTaskIdException();
		}
		
		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("Task Found Successfully with ID: " + id);
		structure.setBody(optional.get());
		
		return new ResponseEntity<A_5ResponseStructure<A_2Task>>(structure, HttpStatus.OK);
	}

	public ResponseEntity<A_5ResponseStructure<String>> deleteTaskById(int id)
	{
		Optional<A_2Task> optional = dao.findTaskById(id);
		
		if(optional.isEmpty())
		{
			throw new A_9InvalidTaskIdException();
		}
		
		A_2Task task = optional.get(); // Getting the object
		
		task.setStatus(A_3Status.DELETED); // Changing the state of the object to deleted
//		Changed the status
		A_2Task dbTask = dao.updateTask(task); // After the state has changed update the task
		
		A_5ResponseStructure<String> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("Task Deleted Successfully");
		structure.setBody("Task Deleted");
		
		return new ResponseEntity<A_5ResponseStructure<String>>(structure, HttpStatus.OK);
	}

	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllPendingTasks()
	{
		List<A_2Task> listOfTasks = dao.findAllTasks();
		ArrayList<A_2Task> al = new ArrayList<>();
		
		for(A_2Task t : listOfTasks)
		{
			if(t.getStatus().toString().equalsIgnoreCase("PENDING"))
			{
				al.add(t);
			}
		}
		
		A_5ResponseStructure<List<A_2Task>> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("All Pending Tasks Found Successfully");
		structure.setBody(al);
		
		return new ResponseEntity<A_5ResponseStructure<List<A_2Task>>>(structure, HttpStatus.OK);
	}
	
	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllCompletedTasks()
	{
		List<A_2Task> listOfTasks = dao.findAllTasks();
		ArrayList<A_2Task> al = new ArrayList<>();
		
		for(A_2Task t : listOfTasks)
		{
			if(t.getStatus().toString().equalsIgnoreCase("COMPLETED"))
			{
				al.add(t);
			}
		}
		
		A_5ResponseStructure<List<A_2Task>> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("All Completed Tasks Found Successfully");
		structure.setBody(al);
		
		return new ResponseEntity<A_5ResponseStructure<List<A_2Task>>>(structure, HttpStatus.OK);
	}
	
	public ResponseEntity<A_5ResponseStructure<List<A_2Task>>> findAllDeletedTasks() {
		List<A_2Task> listOfTasks = dao.findAllTasks();
		ArrayList<A_2Task> al = new ArrayList<>();
		
		for(A_2Task t : listOfTasks)
		{
			if(t.getStatus().toString().equalsIgnoreCase("DELETED"))
			{
				al.add(t);
			}
		}
		
		A_5ResponseStructure<List<A_2Task>> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("All Deleted Tasks Found Successfully");
		structure.setBody(al);
		
		return new ResponseEntity<A_5ResponseStructure<List<A_2Task>>>(structure, HttpStatus.OK);
	}

	public ResponseEntity<A_5ResponseStructure<A_2Task>> setStatusToCompleted(int id)
	{
		Optional<A_2Task> optional = dao.findTaskById(id);
		
		if(optional.isEmpty())
		{
			throw new A_9InvalidTaskIdException();
		}
		
		A_2Task task = optional.get();
		task.setStatus(A_3Status.COMPLETED);
		A_2Task updatedTask = dao.updateTask(task);
		
		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("Task Status Updated to COMPLETED Successfully");
		structure.setBody(updatedTask);
		
		return new ResponseEntity<A_5ResponseStructure<A_2Task>>(structure, HttpStatus.OK);
	}

	public ResponseEntity<A_5ResponseStructure<A_2Task>> setStatusToPending(int id)
	{
		Optional<A_2Task> optional = dao.findTaskById(id);
		
		if(optional.isEmpty())
		{
			throw new A_9InvalidTaskIdException();
		}
		
		A_2Task task = optional.get();
		task.setStatus(A_3Status.PENDING);
		A_2Task updatedTask = dao.updateTask(task);
		
		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("Task Status Updated to PENDING Successfully");
		structure.setBody(updatedTask);
		
		return new ResponseEntity<A_5ResponseStructure<A_2Task>>(structure, HttpStatus.OK);
	}

	public ResponseEntity<A_5ResponseStructure<A_2Task>> setStatusToDeleted(int id)
	{
		Optional<A_2Task> optional = dao.findTaskById(id);
		
		if(optional.isEmpty())
		{
			throw new A_9InvalidTaskIdException();
		}
		
		A_2Task task = optional.get();
		task.setStatus(A_3Status.DELETED);
		A_2Task updatedTask = dao.updateTask(task);
		
		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.OK.value());
		structure.setMessage("Task Status Updated to DELETED Successfully");
		structure.setBody(updatedTask);
		
		return new ResponseEntity<A_5ResponseStructure<A_2Task>>(structure, HttpStatus.OK);
	}
	
	public ResponseEntity<A_5ResponseStructure<A_2Task>> saveTask(A_2Task task)
	{
		task.setStatus(A_3Status.CREATED); // By default status will be created created
		
		A_5ResponseStructure<A_2Task> structure = new A_5ResponseStructure<>();
		structure.setHttpCode(HttpStatus.CREATED.value());
		structure.setMessage("Task Created Successfully");
		structure.setBody(dao.saveTask(task));
		
		return new ResponseEntity<>(structure, HttpStatus.CREATED);
	}
}
