package org.jsp.springEnumProject.exception;

import org.jsp.springEnumProject.A_5ResponseStructure;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class A_10TaskExceptionHandler {
	
	@ExceptionHandler(A_9InvalidTaskIdException.class)
	public ResponseEntity<A_5ResponseStructure<String>> handleDuplicatePhoneNumberException(A_9InvalidTaskIdException e)
	{
		A_5ResponseStructure<String> structure = new A_5ResponseStructure<>();
		
		structure.setHttpCode(HttpStatus.BAD_REQUEST.value());
		structure.setMessage("Task ID does not exist");
		structure.setBody(e.getMessage());
		
		return new ResponseEntity<A_5ResponseStructure<String>>(structure, HttpStatus.BAD_REQUEST);
	}
}
