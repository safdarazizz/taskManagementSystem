package org.jsp.springEnumProject.util;

public enum A_3Status {
	
	CREATED, PENDING, COMPLETED, DELETED;
}
