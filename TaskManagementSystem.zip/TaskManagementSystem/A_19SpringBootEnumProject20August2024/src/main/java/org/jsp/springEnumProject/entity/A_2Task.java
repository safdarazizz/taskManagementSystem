package org.jsp.springEnumProject.entity;

import java.time.LocalDateTime;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.jsp.springEnumProject.util.A_3Status;

import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class A_2Task {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String title;
	private String description;
	
	@Enumerated(EnumType.STRING) // Stores in the form of String in DB
	private A_3Status status;
	
	@CreationTimestamp
	private LocalDateTime assignedDate;
	
	@UpdateTimestamp
	private LocalDateTime completedDate;
}
