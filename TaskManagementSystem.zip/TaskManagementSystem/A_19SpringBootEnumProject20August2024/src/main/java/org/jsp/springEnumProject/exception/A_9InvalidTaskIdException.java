package org.jsp.springEnumProject.exception;

public class A_9InvalidTaskIdException extends RuntimeException {
	
	@Override
	public String getMessage() {
		return "Task ID does not exist, Try with a new one!";
	}
}
