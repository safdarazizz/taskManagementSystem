package org.jsp.springEnumProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class A_1SpringBootEnumProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
